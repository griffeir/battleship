import ecs100.*;
import java.util.ArrayList;

/**
 * Holds a collection of tiles in a 2d array
 * These tiles could hold a ship
 *
 * @author Ira
 * @version 13/9/21
 */
public class Board
{
    // fields
    private Tile board[][]; // 2d array for storing tiles
    
    // booleans for storing which phase the game is in
    boolean shipPhase = true; // for placing ships at the start
    boolean battlePhase = false; // for when ships are placed
    boolean endPhase = false; // for when the game is over
    // constants for board info
    static final int NUMROWS = 10;
    static final int NUMCOLUMNS = 10;
    final int NUMSHIPS = 5;
    // placing ships
    private int firstTileY;
    private int firstTileX;
    private ArrayList<Ship> ships;
    boolean placed = false;
    private String action = "";
    private boolean tileClickToggle = false;
    private boolean collision = false;
    private boolean placingShip = false; // Stops user clicking while waiting for keypress
    
    /**
     * Constructor for objects of class Board
     */
    public Board()
    {
        // initialise instance variables
        board = new Tile[NUMROWS][NUMCOLUMNS];
        ships = new ArrayList<Ship>();
        this.fillBoard();
        this.drawBoard();
        this.fillShips();
    }
    
    /**
     * Run the main game
     */
    public void playGame(){
        UI.println("Click a tile to shoot there");
    }
    
    /**
     * Creates ships to be played with
     */
    public void fillShips(){
       String[] shipNames = {"carrier", "battleship", "destroyer", 
           "submarine", "patrol boat"};
       int[] shipLengths = {5, 4, 3, 3, 2};
       for(int x = 0; x < shipNames.length; x++) {
            ships.add(new Ship(shipNames[x], shipLengths[x], 0));
       }
    }
    
    /**
     * Fills the board with tiles
     */
    public void fillBoard(){
        for (int row = 0; row < board.length; row++){
            for (int col = 0; col < board[row].length; col++)
            {
                board[col][row] = new Tile(col, row, false); 
                // Puts a tile in this spot
            }
        }
    }
    
    /**
     * Calls each tile to draw itself
     * by looping through board
     */
    public void drawBoard(){
        for (int row = 0; row < board.length; row++)
        {
            for (int col = 0; col < board[row].length; col++)
            {
                board[col][row].drawSea(); // call Tile method
            }
        }
    }
    
    /**
     * places ships
     */
    public void placeShips(){
        // place ships
        /* ships to place = 5 long carrier, 4 long battleship,
        * 3 long destroyer, 3 long submarine, 2 long patrol boat
        */
        for(int x = 0; x < ships.size(); x++){
            UI.println("Please select start location for ship");
            while(!placed){ 
                if(tileClickToggle){
                    // place ship in direction of keypress, check for collisions with the side of the board or with other ships
                    if(action.equals("w")){
                        int finalTileY = firstTileY + 1 - ships.get(x).getSize();
                        if(finalTileY >= 0){
                            for(int o = 0; o < ships.get(x).getSize(); o++) {
                                if(board[firstTileX][firstTileY - o].getShipCheck()){
                                    collision = true;
                                }
                            }
                            if(!collision){
                                // print out ships as they're placed
                                for(int i = 0; i < ships.get(x).getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileX][firstTileY - i].drawShip();
                                    board[firstTileX][firstTileY - i].setShipCheck();
                                    // put the ship into the tile
                                    board[firstTileX][firstTileY  - i].setShip(ships.get(x));
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                                
                            }
                            else{
                                UI.println("collision");
                            }
                        }
                    }
                    
                    else if(action.equals("a")){
                        int finalTileX = firstTileX + 1 - ships.get(x).getSize();
                        if(finalTileX >= 0) {
                            for(int o = 0; o < ships.get(x).getSize(); o++) {
                                if(board[firstTileX - o][firstTileY].getShipCheck()){
                                    collision = true;
                                }
                            }
                            if(!collision){
                                // print out ships as they're placed
                                for(int i = 0; i < ships.get(x).getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileX - i][firstTileY].drawShip();
                                    board[firstTileX - i][firstTileY].setShipCheck();
                                    // put the ship into the tile
                                    board[firstTileX - i][firstTileY].setShip(ships.get(x));
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                            }
                        } 
                    }
                    else if(action.equals("s")){
                        int finalTileY = firstTileY + ships.get(x).getSize();
                        if(finalTileY <= NUMROWS) {
                            for(int o = 0; o < ships.get(x).getSize(); o++) {
                                if(board[firstTileX][firstTileY + o].getShipCheck()){
                                    collision = true;
                                }
                            }
                            if(!collision){
                                // print out ships as they're placed
                                for(int i = 0; i < ships.get(x).getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileX][firstTileY + i].drawShip();
                                    board[firstTileX][firstTileY + i].setShipCheck();
                                    // put the ship into the tile
                                    board[firstTileX][firstTileY + i].setShip(ships.get(x));
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                            }
                        }
                    }
                    else if(action.equals("d")){
                        int finalTileX = firstTileX + ships.get(x).getSize();
                        if(finalTileX <= NUMCOLUMNS) {
                            for(int o = 0; o < ships.get(x).getSize(); o++) {
                                if(board[firstTileX + o][firstTileY].getShipCheck()){
                                    collision = true;
                                }
                            }
                            // print out ships as they're placed
                            if(!collision){
                                for(int i = 0; i < ships.get(x).getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileX + i][firstTileY].drawShip();
                                    board[firstTileX + i][firstTileY].setShipCheck();
                                    // put the ship into the tile
                                    board[firstTileX + i][firstTileY].setShip(ships.get(x));
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                            }
                        }
                    }
                }
                // reset loop vars
                collision = false;
                action = "";
                /* stop an error where while loop stops key listener 
                from properly giving action*/
                try{
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                }
            }
            placed = false;
            placingShip = false;
        }
        setPhase();
    }
    
    /**
     * For when a tile is clicked
     * Checks whether a ship needs to be placed
     * Or a shot fired
     */
    public void tileClicked(int mouseX, int mouseY){
        if (shipPhase){
            placingShip = true;
            firstTileY = mouseY;
            firstTileX = mouseX;
            UI.println("Please press key for direction you want ship to go");
            board[firstTileX][firstTileY].startTile();
        }
        else if (battlePhase){
            //check whether the tile they clicked has already been hit or not
            if(!board[mouseX][mouseY].getHit()){
                board[mouseX][mouseY].setHit();
                // check if they hit a ship or the sea
                if(board[mouseX][mouseY].getShipCheck()){
                    this.hitShip(mouseY, mouseX);
                } else {
                    board[mouseX][mouseY].hitSea();
                }
            } else {
                UI.println("This tile has already been hit");
            }
        }
    }
    
    /**
     * processes a ship being hit
     */
    public void hitShip(int mouseY, int mouseX){
        UI.println("You hit a ship");
        board[mouseX][mouseY].getShip().setHitCount();
        board[mouseX][mouseY].hitShip();
        // check if ship has been hit on every tile it covers: sink it
        if(board[mouseX][mouseY].getShip().getHitCount() == board[mouseX][mouseY].getShip().getSize()) {
            UI.println("You have sunk their " + board[mouseX][mouseY].getShip().getName());
            Ship tileShip = board[mouseX][mouseY].getShip(); // store the ship so that we can remember it when reference from tile is gone
            
            // loop through board and remove ship from tiles
            for (int row = 0; row < board.length; row++)
            {
                for (int col = 0; col < board[row].length; col++)
                {
                    if(board[col][row].getShip() != null){
                        if(board[col][row].getShip().getName() == tileShip.getName()){
                            board[col][row].removeShip();
                        }
                    }
                }
            }
            ships.remove(tileShip); // remove this ship from ships arrayList
            if(ships.size() == 0){ // check if ships arrayList is empty
                UI.println("Congratulations, you have won");
                setPhase();
            }
        }    
    }
    
    /**
     * Getter for placingShip
     * 
     * @return placingShip
     */
    public boolean getPlacingShip(){
        return placingShip;
    }
    
    /**
     * Getter for board
     * 
     * @return board
     */
    public Tile[][] getBoard(){
        return this.board;
    }
    
    /**
     * Setter for keyboard action
     */
    public void setAction(String action){
        this.action = action;
    }
    
    /**
     * Setter for phase
     */
    public void setPhase(){
        if(shipPhase){
            shipPhase = false;
            battlePhase = true;
        } else if(battlePhase){
            battlePhase = false;
            endPhase = true;
        }
    }
    
    /**
     * 
     */
    public void setTileClicked(boolean clickedStatus){
        this.tileClickToggle = clickedStatus;
    }
}