import ecs100.*;
import java.awt.Color;

/**
 * Support class of board
 * A tile holds x, y coordinates
 * and whether or not a ship is currently on the tile
 *
 * @author Ira
 * @version 13/9/21
 */
public class Tile
{
    // fields
    private int x;
    private int y;
    private boolean shipCheck; // stores whether a ship is present
    static final int TILESIZE = 40; // size of the tile when printed
    private Ship ship;
    private boolean hit = false; 
    private Color color;
    private boolean shipSunk = false;
    /**
     * Constructor for objects of class tile
     * 
     */
    public Tile(int x, int y, boolean shipCheck) {
        //initialise instance variables
        this.x = x;
        this.y = y;
        this.shipCheck = shipCheck;
    }
    
    /**
     * Getter for x
     * 
     * @return x
     */
    public int getX() {
        return this.x;   
    }
    
    /**eck
     * Getter for y
     * 
     * @return y
     */
    public int getY() {
        return this.y;   
    }
    
    /**
     * Getter for shipCheck
     * 
     * @return shipCheck
     */
    public boolean getShipCheck() {
        return this.shipCheck;   
    }
    
    /**
     * Getter for ship
     * 
     * @return ship
     */
    public Ship getShip() {
        return this.ship;   
    }
    
    /**
     * Getter for hit
     * 
     * @return hit
     */
    public boolean getHit() {
        return this.hit;   
    }
    
    /**
     * Setter for hit
     * 
     */
    public void setHit() {
        this.hit = true; 
    }
    
    /**
     * Getter for shipSunk
     */
    public boolean getShipSunk(){
        return this.shipSunk;
    }
    
    /**
     * Setter for ship
     * 
     */
    public void setShip(Ship ship) {
         this.ship = ship;
    }
    
    /**
     * Remove a ship
     */
    public void removeShip(){
        this.ship = null;
        setShipCheck();
        shipSunk = true;
        sunkenShip();
    }
    
    /**
     * Draw a sunken ship
     */
    public void sunkenShip(){
        color = Color.black;
        drawTile(color);
    }
    
    /**
     * Setter for shipCheck
     * 
     * @return shipCheck
     */
    public boolean setShipCheck() {
        if(this.shipCheck == false) {
            this.shipCheck = true;
        }
        else{
            this.shipCheck = false;
        }
        return this.shipCheck;
    }
    
    /**
     * Draw tiles
     */
    public void drawTile(Color color){
        UI.setColor(color);
        UI.fillRect(x * TILESIZE, y * TILESIZE, TILESIZE, TILESIZE);
        UI.setColor(Color.black);
        UI.drawRect(x * TILESIZE, y * TILESIZE, TILESIZE, TILESIZE);
    }
    
    /**
     * Draw sea
     */
    public void drawSea(){
        color = Color.blue;
        drawTile(color);
    }
    
    /**
     * Process when a ship is hit
     */
    public void hitShip(){
        color = Color.red;
        drawTile(color);
    }
    
    /**
     * Process when a tile is hit
     */
    public void hitSea(){
        color = Color.orange;
        drawTile(color);
    }
    
    public void startTile(){
        color = Color.green;
        drawTile(color);
    }
    
    public void drawShip() {
        color = Color.gray;
        drawTile(color);
    }
}
