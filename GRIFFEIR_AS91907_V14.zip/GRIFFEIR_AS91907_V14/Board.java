import ecs100.*;
import java.util.ArrayList;

/**
 * Holds a collection of tiles in a 2d array
 * These tiles could hold a ship
 *
 * @author Ira
 * @version 13/9/21
 */
public class Board
{
    // fields
    private Tile pOneBoard[][]; // 2d array for storing tiles
    private Tile pTwoBoard[][];
    
    // booleans for storing which phase the game is in
    boolean shipPhase = true; // for placing pOneShips at the start
    boolean battlePhase = false; // for when pOneShips are placed
    boolean endPhase = false; // for when the game is over
    boolean pOneTurn = true;
    boolean pTwoTurn = false;
    
    // constants for board info
    static final int NUMROWS = 10;
    static final int NUMCOLUMNS = 10;
    final int NUMSHIPS = 5;
    
    // placing Ships
    private int firstTileY;
    private int firstTileX;
    private ArrayList<Ship> pOneShips;
    private ArrayList<Ship> pTwoShips;
    boolean placed = false;
    private String action = "";
    private boolean tileClickToggle = false;
    private boolean collision = false;
    private boolean placingShip = false; // Stops user clicking while waiting for keypress
    
    /**
     * Constructor for objects of class Board
     */
    public Board()
    {
        // initialise instance variables
        pOneBoard = new Tile[NUMCOLUMNS][NUMROWS];
        pTwoBoard = new Tile[NUMCOLUMNS][NUMROWS];
        pOneShips = new ArrayList<Ship>();
        pTwoShips = new ArrayList<Ship>();
        this.fillBoards();
        this.fillShips();
    }
    
    /**
     * Run the main game
     */
    public void playGame(){
        UI.println("Click a tile to shoot there");
    }
    
    /**
     * Draw screen showing whose turn it is
     */
    public void drawTurn(){
        UI.setFontSize(20);
        UI.clearGraphics();
        if(pOneTurn){
            UI.drawString("Player One Turn", 200, 200);
        } else {
            UI.drawString("Player Two Turn", 200, 200);
        }
        try{
            Thread.sleep(1000);
        } catch (InterruptedException e) {
        }
    }
    
    /**
     * Creates Ships to be played with
     */
    public void fillShips(){
       String[] shipNames = {"carrier", "battleship", "destroyer", 
           "submarine", "patrol boat"};
       int[] shipLengths = {5, 4, 3, 3, 2};
       for(int x = 0; x < shipNames.length; x++) {
            pOneShips.add(new Ship(shipNames[x], shipLengths[x], 0));
            pTwoShips.add(new Ship(shipNames[x], shipLengths[x], 0));
       }
    }
    
    /**
     * Fills the board with tiles
     */
    public void fillBoards(){
        for (int row = 0; row < NUMROWS; row++){
            for (int col = 0; col < NUMCOLUMNS; col++)
            {
                pOneBoard[col][row] = new Tile(col, row, false); 
                pTwoBoard[col][row] = new Tile(col, row, false); 
                // Puts a tile in this spot
            }
        }
    }
    
    /**
     * Calls each tile to draw itself
     * by looping through board
     */
    public void drawBoard(Tile board[][]){
        UI.clearGraphics();
        for (int row = 0; row < NUMROWS; row++)
        {
            for (int col = 0; col < NUMCOLUMNS; col++)
            {
                if(board[col][row].getShipCheck() && board[col][row].getHit()){
                    board[col][row].hitShip();
                } else if(!board[col][row].getShipCheck() && board[col][row].getHit()){
                    if(board[col][row].getShipSunk()){
                        board[col][row].sunkenShip();
                    } else {
                        board[col][row].hitSea();
                    }
                } else{
                    board[col][row].drawSea(); // call Tile method
                }
            }
        }
    }
    
    /**
     * Place pOneShips
     */
    public void placePOneShips(){
        drawTurn();
        placeShips(pOneShips, pOneBoard);
    }
    
    /**
     * Place pTwoShips
     */
    public void placePTwoShips(){
        placeShips(pTwoShips, pTwoBoard);
        drawBoard(pTwoBoard);
    }
    
    /**
     * places Ships
     */
    public void placeShips(ArrayList<Ship> ships, Tile board[][]){
        // place Ships
        /* ships to place = 5 long carrier, 4 long battleship,
        * 3 long destroyer, 3 long submarine, 2 long patrol boat
        */
        drawBoard(board);
        for(int x = 0; x < NUMSHIPS; x++){
            UI.println("Please select start location for ship");
            while(!placed){ 
                if(tileClickToggle){
                    // place ship in direction of keypress, check for collisions with the side of the board or with other Ships
                    if(action.equals("w")){
                        int finalTileY = firstTileY + 1 - ships.get(x).getSize();
                        if(finalTileY >= 0){
                            for(int o = 0; o < ships.get(x).getSize(); o++) {
                                if(board[firstTileX][firstTileY - o].getShipCheck()){
                                    collision = true;
                                }
                            }
                            if(!collision){
                                // print out Ships as they're placed
                                for(int i = 0; i < ships.get(x).getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileX][firstTileY - i].drawShip();
                                    board[firstTileX][firstTileY - i].setShipCheck();
                                    // put the ship into the tile
                                    board[firstTileX][firstTileY  - i].setShip(ships.get(x));
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                                
                            }
                            else{
                                UI.println("collision");
                            }
                        }
                    }
                    
                    else if(action.equals("a")){
                        int finalTileX = firstTileX + 1 - ships.get(x).getSize();
                        if(finalTileX >= 0) {
                            for(int o = 0; o < ships.get(x).getSize(); o++) {
                                if(board[firstTileX - o][firstTileY].getShipCheck()){
                                    collision = true;
                                }
                            }
                            if(!collision){
                                // print out ships as they're placed
                                for(int i = 0; i < ships.get(x).getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileX - i][firstTileY].drawShip();
                                    board[firstTileX - i][firstTileY].setShipCheck();
                                    // put the ship into the tile
                                    board[firstTileX - i][firstTileY].setShip(ships.get(x));
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                            }
                        } 
                    }
                    else if(action.equals("s")){
                        int finalTileY = firstTileY + ships.get(x).getSize();
                        if(finalTileY <= NUMROWS) {
                            for(int o = 0; o < ships.get(x).getSize(); o++) {
                                if(board[firstTileX][firstTileY + o].getShipCheck()){
                                    collision = true;
                                }
                            }
                            if(!collision){
                                // print out ships as they're placed
                                for(int i = 0; i < ships.get(x).getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileX][firstTileY + i].drawShip();
                                    board[firstTileX][firstTileY + i].setShipCheck();
                                    // put the ship into the tile
                                    board[firstTileX][firstTileY + i].setShip(ships.get(x));
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                            }
                        }
                    }
                    else if(action.equals("d")){
                        int finalTileX = firstTileX + ships.get(x).getSize();
                        if(finalTileX <= NUMCOLUMNS) {
                            for(int o = 0; o < ships.get(x).getSize(); o++) {
                                if(board[firstTileX + o][firstTileY].getShipCheck()){
                                    collision = true;
                                }
                            }
                            // print out ships as they're placed
                            if(!collision){
                                for(int i = 0; i < ships.get(x).getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileX + i][firstTileY].drawShip();
                                    board[firstTileX + i][firstTileY].setShipCheck();
                                    // put the ship into the tile
                                    board[firstTileX + i][firstTileY].setShip(ships.get(x));
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                            }
                        }
                    }
                }
                // reset loop vars
                collision = false;
                action = "";
                /* stop an error where while loop stops key listener 
                from properly giving action*/
                try{
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                }
            }
            placed = false;
            placingShip = false;
            
        }
        // pause for a second before switching turn
        try{
            Thread.sleep(1000); 
        } catch (InterruptedException e) {
        }
        setTurn();
        drawTurn();
    }
    
    /**
     * For when a tile is clicked
     * Checks whether a ship needs to be placed
     * Or a shot fired
     */
    public void tileClicked(int mouseX, int mouseY){
        if (shipPhase){   
            if(pOneTurn){
                if(!pOneBoard[mouseX][mouseY].getShipCheck()){ // make sure there is not a ship on the tile
                    if(placingShip){
                        pOneBoard[firstTileX][firstTileY].drawSea(); // if there was already a start tile selected redraw it as sea
                    }
                    placingShip = true;
                    UI.println("Please press key for direction you want ship to go");
                    pOneBoard[mouseX][mouseY].startTile();
                } else{
                    UI.println("There is already a ship here");
                }
            } else if(pTwoTurn){  
                if(!pTwoBoard[mouseX][mouseY].getShipCheck()){  // make sure there is not a ship on the tile
                    if(placingShip){
                        pTwoBoard[firstTileX][firstTileY].drawSea(); // if there was already a start tile selected redraw it as sea
                    }
                    placingShip = true;
                    UI.println("Please press key for direction you want ship to go");
                    pTwoBoard[mouseX][mouseY].startTile();
                } else{
                    UI.println("There is already a ship here");
                }
            }   
            firstTileX = mouseX;
            firstTileY = mouseY;
        }
        else if (battlePhase){
            //check whether the tile they clicked has already been hit or not
            if(pOneTurn){
                this.drawBoard(pTwoBoard);
                if(!pTwoBoard[mouseX][mouseY].getHit()){
                    pTwoBoard[mouseX][mouseY].setHit();
                    // check if they hit a ship or the sea
                    if(pTwoBoard[mouseX][mouseY].getShipCheck()){
                        this.hitShip(mouseY, mouseX, pTwoBoard, pTwoShips);
                    } else {
                        pTwoBoard[mouseX][mouseY].hitSea();
                    }
                    // pause for a second so they can see whether they hit or not
                    try{
                        Thread.sleep(1000); 
                    } catch (InterruptedException e) {
                    }
                    setTurn();
                    drawTurn();
                    drawBoard(pOneBoard);
                } else {
                    UI.println("This tile has already been hit");
                }
            } else if(pTwoTurn) {
                if(!pOneBoard[mouseX][mouseY].getHit()){
                    pOneBoard[mouseX][mouseY].setHit();
                    // check if they hit a ship or the sea
                    if(pOneBoard[mouseX][mouseY].getShipCheck()){
                        this.hitShip(mouseY, mouseX, pOneBoard, pOneShips);
                    } else {
                        pOneBoard[mouseX][mouseY].hitSea();
                    }
                    // pause for a second so they can see whether they hit or not
                    try{
                        Thread.sleep(1000); 
                    } catch (InterruptedException e) {
                    }
                    setTurn();
                    drawTurn();
                    drawBoard(pTwoBoard);
                } else {
                    UI.println("This tile has already been hit");
                }
            }
        }
    }
    
    /**
     * processes a ship being hit
     */
    public void hitShip(int mouseY, int mouseX, Tile[][] board, ArrayList<Ship> ships){
        UI.println("You hit a ship");
        board[mouseX][mouseY].getShip().setHitCount(); // tell the ship it has been hit
        board[mouseX][mouseY].hitShip(); // draw the ship being hit
        // check if ship has been hit on every tile it covers: sink it
        if(board[mouseX][mouseY].getShip().getHitCount() == board[mouseX][mouseY].getShip().getSize()) {
            UI.println("You have sunk their " + board[mouseX][mouseY].getShip().getName());
            Ship tileShip = board[mouseX][mouseY].getShip(); // store the ship so that we can remember it when reference from tile is gone
            
            // loop through board and remove ship from tiles
            for (int row = 0; row < board.length; row++)
            {
                for (int col = 0; col < board[row].length; col++)
                {
                    if(board[col][row].getShipCheck()){
                        if(board[col][row].getShip().getName() == tileShip.getName()){
                            board[col][row].removeShip();
                        }
                    }
                }
            }
            ships.remove(tileShip); // remove this ship from ships arrayList
            if(ships.size() == 0){ // check if ships arrayList is empty
                UI.println("Congratulations, you have won");
                setPhase();
            }
        }    
    }
    
    /**
     * Getter for placingShip
     * 
     * @return placingShip
     */
    public boolean getPlacingShip(){
        return placingShip;
    }
    
    /**
     * Getter for board
     * 
     * @return board
     */
    public Tile[][] getBoard(){
        return this.pOneBoard;
    }
    
    /**
     * Setter for keyboard action
     */
    public void setAction(String action){
        this.action = action;
    }
    
    /**
     * Setter for phase
     */
    public void setPhase(){
        if(shipPhase){
            shipPhase = false;
            battlePhase = true;
        } else if(battlePhase){
            battlePhase = false;
            endPhase = true;
        }
    }
    
    /**
     * Setter for turn
     */
    public void setTurn(){
        if(pOneTurn){
            pOneTurn = false;
            pTwoTurn = true;
        } else if(pTwoTurn){
            pTwoTurn = false;
            pOneTurn = true;
        }
    }
    
    /**
     * 
     */
    public void setTileClicked(boolean clickedStatus){
        this.tileClickToggle = clickedStatus;
    }
}