import ecs100.*;

/**
 * Class to handle the GUI functionality
 *
 * @author Ira
 * @version 14/9/21
 */
public class GUI
{
    // fields
    private Board bd; // declare instance of board
    static final int TILESIZE = 40;
    private String action;
    /**
     * Constructor for objects of class GUI
     */
    public GUI()
    {
        // initialise instance variables
        UI.initialise();
        UI.addButton("Quit", UI::quit);
        UI.addButton("Help", this::help);
        bd = new Board();
        
        // set mouse listener and key listener
        UI.setMouseListener(this::doMouse);
        UI.setKeyListener(this::recordKey);
        this.placeShips();
        bd.playGame();
    }
    
    public void placeShips(){
        bd.placePOneShips();
        bd.placePTwoShips();
        bd.setPhase();
    }
    
    public void help(){
        bd.help();
    }
    /**
     * 
     * @param action action the mouse has performed
     * @param x x pos of the mouse click
     * @param y y pos of mouse click
     */
    public void doMouse(String action, double x, double y) {  
        if (action.equals("pressed")) {
            // save mouse pos divided by the size of the tiles
            // check if x and y are inside grid
            try{
                if(x / TILESIZE <= 10 && y / TILESIZE <= 10){
                    int mouseX = (int)(x / TILESIZE);
                    int mouseY = (int)(y / TILESIZE);
                    bd.tileClicked(mouseX, mouseY);
                    bd.setTileClicked(true);
                }
            }   
            catch(Exception ex){
            }
        }
    }
    
    /**
     * 
     * @param action action the keyboard has performed
     */
    public void recordKey(String action) { 
        if (action.equals("w") || action.equals("a") 
        || action.equals("s") || action.equals("d")) {
            bd.setAction(action); // sends this action to board class to use there
        }
    }
}


