import ecs100.*;
import java.awt.Color;

/**
 * Support class of board
 * A tile holds x, y coordinates
 * and whether or not a ship is currently on the tile
 *
 * @author Ira
 * @version 13/9/21
 */
public class Tile
{
    // fields
    private int x;
    private int y;
    private boolean ship; // stores whether a ship is present
    static final int TILESIZE = 40; // size of the tile when printed
    
    /**
     * Constructor for objects of class tile
     * 
     */
    public Tile(int x, int y, boolean ship) {
        //initialise instance variables
        this.x = x;
        this.y = y;
        this.ship = ship;
    }
    
    /**
     * Getter for x
     * 
     * @return x
     */
    public int getX() {
        return this.x;   
    }
    
    /**
     * Getter for y
     * 
     * @return y
     */
    public int getY() {
        return this.y;   
    }
    
    /**
     * Getter for Ship
     * 
     * @return ship
     */
    public boolean getShip() {
        return this.ship;   
    }
    
    /**
     * Setter for Ship
     * 
     * @return ship
     */
    public boolean setShip() {
        if(this.ship == false) {
            this.ship = true;
        }
        else{
            this.ship = false;
        }
        return this.ship;
    }
    
    /**
     * Draw tiles
     */
    public void drawTile(){
        UI.setColor(Color.black);
        UI.drawRect(x * TILESIZE, y * TILESIZE, TILESIZE, TILESIZE);
    }
    
    /**
     * Process when a tile is hit
     */
    public void hitTile(){
        UI.setColor(Color.red);
        UI.fillRect(x * TILESIZE, y * TILESIZE, TILESIZE, TILESIZE);
    }
}
