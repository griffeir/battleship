import ecs100.*;
/**
 * Holds a collection of tiles in a 2d array
 * These tiles could hold a ship
 *
 * @author Ira
 * @version 13/9/21
 */
public class Board
{
    // fields
    private Tile board[][]; // 2d array for storing tiles
    
    // booleans for storing which phase the game is in
    boolean shipPhase = false; // for placing ships at the start
    boolean battlePhase = true; // for when ships are placed
    // constants for board info
    static final int NUMROWS = 10;
    static final int NUMCOLUMNS = 10;
    final int NUMSHIPS = 5;
    // placing ships
    int firstTileX;
    int firstTileY;
    

    /**
     * Constructor for objects of class Board
     */
    public Board()
    {
        // initialise instance variables
        board = new Tile[NUMROWS][NUMCOLUMNS];
        this.fillBoard();
    }
    
    /**
     * Fills the board with tiles
     */
    public Tile[][] fillBoard(){
        for (int row = 0; row < board.length; row++)
        {
            for (int col = 0; col < board[row].length; col++)
            {
                board[row][col] = new Tile(col, row, false); 
                // Puts a tile in this spot
            }
            // place ships
            /* ships to place = 5 long carrier, 4 long battleship,
             * 3 long destroyer, 3 long submarine, 2 long patrol boat
             */
            UI.println("Please select start location for ship");
        }
        return this.board;
    }
    
    /**
     * Calls each tile to draw itself
     * by looping through board
     */
    public void drawBoard(){
        for (int row = 0; row < board.length; row++)
        {
            for (int col = 0; col < board[row].length; col++)
            {
                board[row][col].drawTile(); // call Tile method
            }
        }
    }
    
    /**
     * For when a tile is clicked
     * Checks whether a ship needs to be placed
     * Or a shot fired
     */
    public void tileClicked(int mouseX, int mouseY){
        if (shipPhase == true){
            firstTileX = mouseX;
            firstTileY = mouseY;
            UI.println("Please select end location");
        }
        else if (battlePhase == true){
            board[mouseY][mouseX].hitTile(); 
        }
    }
    
    /**
     * Getter for board
     * 
     * @return board
     */
    public Tile[][] getBoard(){
        return this.board;
    }
}
