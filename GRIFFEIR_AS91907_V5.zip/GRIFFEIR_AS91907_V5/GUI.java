import ecs100.*;

/**
 * Class to handle the GUI functionality
 *
 * @author Ira
 * @version 14/9/21
 */
public class GUI
{
    // fields
    private Board bd; // declare instance of board
    private Tile board[][];
    static final int TILESIZE = 40;
    
    /**
     * Constructor for objects of class GUI
     */
    public GUI()
    {
        // initialise instance variables
        bd = new Board();
        UI.initialise();
        printBoard();
        UI.addButton("Quit", UI::quit);
        
        // set mouse listener
        UI.setMouseListener(this::doMouse);
    }
    
    /**
     * Prints the board
     */
    public void printBoard() 
    {
        bd.drawBoard();
    }
    
    /**
     * Check if the user has clicked within the img
     * then clear pane
     * 
     * @param action action the mouse has performed
     * @param x x pos of the mouse click
     * @param y y pos of mouse click
     */
    public void doMouse(String action, double x, double y) {  
        if (action.equals("pressed")) {
            // save mouse pos divided by the size of the tiles
            // check if x and y are inside grid
            try{
                int mouseX = (int)(x / TILESIZE);
                int mouseY = (int)(y / TILESIZE); 
                bd.tileClicked(mouseX, mouseY);
            }   
            catch(Exception ex){
            }
        }
    }
}


