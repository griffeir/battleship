import ecs100.*;

/**
 * Holds a collection of tiles in a 2d array
 * These tiles could hold a ship
 *
 * @author Ira
 * @version 13/9/21
 */
public class Board
{
    // fields
    private Tile board[][]; // 2d array for storing tiles
    
    // booleans for storing which phase the game is in
    boolean shipPhase = true; // for placing ships at the start
    boolean battlePhase = false; // for when ships are placed
    // constants for board info
    static final int NUMROWS = 10;
    static final int NUMCOLUMNS = 10;
    final int NUMSHIPS = 5;
    // placing ships
    private int firstTileX;
    private int firstTileY;
    private Ship ships[];
    boolean placed = false;
    private String action = "";
    private boolean tileClickToggle = false;
    private boolean collision = false;
    
    /**
     * Constructor for objects of class Board
     */
    public Board()
    {
        // initialise instance variables
        board = new Tile[NUMROWS][NUMCOLUMNS];
        ships = new Ship[NUMSHIPS];
        this.fillBoard();
        this.drawBoard();
        this.fillShips();
    }
    
    public void fillShips(){
       String[] shipNames = {"carrier", "battleship", "destroyer", 
           "submarine", "patrol boat"};
       int[] shipLengths = {5, 4, 3, 3, 2};
       for(int x = 0; x < shipNames.length; x++) {
            ships[x] = new Ship(shipNames[x], shipLengths[x], 0);
       }
    }
    
    /**
     * Fills the board with tiles
     */
    public void fillBoard(){
        for (int row = 0; row < board.length; row++){
            for (int col = 0; col < board[row].length; col++)
            {
                board[row][col] = new Tile(col, row, false); 
                // Puts a tile in this spot
            }
        }
    }
    
    /**
     * Calls each tile to draw itself
     * by looping through board
     */
    public void drawBoard(){
        for (int row = 0; row < board.length; row++)
        {
            for (int col = 0; col < board[row].length; col++)
            {
                board[row][col].drawTile(); // call Tile method
            }
        }
    }
    
    /**
     * places ships
     */
    public void placeShips(){
        // place ships
        /* ships to place = 5 long carrier, 4 long battleship,
        * 3 long destroyer, 3 long submarine, 2 long patrol boat
        */
        for(int x = 0; x < ships.length; x++){
            UI.println("Please select start location for ship");
            while(!placed){ 
                if(tileClickToggle){
                    // place ship in direction of keypress, check for collisions with the side of the board or with other ships
                    if(action.equals("w")){
                        int finalTileY = firstTileY + 1 - ships[x].getSize();
                        if(finalTileY >= 0){
                            for(int o = 0; o < ships[x].getSize(); o++) {
                                if(board[firstTileY - o][firstTileX].getShip()){
                                    collision = true;
                                }
                            }
                            if(!collision){
                                // print out ships as they're placed
                                for(int i = 0; i < ships[x].getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileY - i][firstTileX].drawShip();
                                    board[firstTileY - i][firstTileX].setShip();
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                                
                            }
                            else{
                                UI.println("collision");
                            }
                        }
                    }
                    
                    else if(action.equals("a")){
                        int finalTileX = firstTileX + 1 - ships[x].getSize();
                        if(finalTileX >= 0) {
                            for(int o = 0; o < ships[x].getSize(); o++) {
                                if(board[firstTileY][firstTileX - o].getShip()){
                                    collision = true;
                                }
                            }
                            if(!collision){
                                // print out ships as they're placed
                                for(int i = 0; i < ships[x].getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileY][firstTileX - i].drawShip();
                                    board[firstTileY][firstTileX - i].setShip();
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                            }
                        } 
                    }
                    else if(action.equals("s")){
                        int finalTileY = firstTileY + ships[x].getSize();
                        if(finalTileY <= NUMROWS) {
                            for(int o = 0; o < ships[x].getSize(); o++) {
                                if(board[firstTileY + o][firstTileX].getShip()){
                                    collision = true;
                                }
                            }
                            if(!collision){
                                // print out ships as they're placed
                                for(int i = 0; i < ships[x].getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileY + i][firstTileX].drawShip();
                                    board[firstTileY + i][firstTileX].setShip();
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                            }
                        }
                    }
                    else if(action.equals("d")){
                        int finalTileX = firstTileX + ships[x].getSize();
                        if(finalTileX <= NUMCOLUMNS) {
                            for(int o = 0; o < ships[x].getSize(); o++) {
                                if(board[firstTileY][firstTileX + o].getShip()){
                                    collision = true;
                                }
                            }
                            // print out ships as they're placed
                            if(!collision){
                                for(int i = 0; i < ships[x].getSize(); i++) {
                                    // draw ship and tell tile that it has a ship on it
                                    board[firstTileY][firstTileX + i].drawShip();
                                    board[firstTileY][firstTileX + i].setShip();
                                }
                                //reset loop vars
                                placed = true;
                                tileClickToggle = false;
                            }
                        }
                    }
                }
                // reset loop vars
                collision = false;
                action = "";
                /* stop an error where while loop stops key listener 
                from properly giving action*/
                try{
                    Thread.sleep(1);
                } catch (InterruptedException e) {
                }
            }
            placed = false;
        }
    }
    
    /**
     * For when a tile is clicked
     * Checks whether a ship needs to be placed
     * Or a shot fired
     */
    public void tileClicked(int mouseX, int mouseY){
        if (shipPhase){
            firstTileX = mouseX;
            firstTileY = mouseY;
            UI.println(firstTileX);
            UI.println(firstTileY);
            UI.println("Please press key for direction you want ship to go");
            board[firstTileY][firstTileX].startTile();
        }
        else if (battlePhase){
            board[mouseY][mouseX].hitTile(); 
        }
    }
    
    /**
     * Getter for board
     * 
     * @return board
     */
    public Tile[][] getBoard(){
        return this.board;
    }
    
    /**
     * Setter for keyboard action
     */
    public void setAction(String action){
        this.action = action;
    }
    
    /**
     * 
     */
    public void setTileClicked(boolean clickedStatus){
        this.tileClickToggle = clickedStatus;
    }
}